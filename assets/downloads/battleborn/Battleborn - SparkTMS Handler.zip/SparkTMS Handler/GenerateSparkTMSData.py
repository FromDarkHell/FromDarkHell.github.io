import requests
import os
import subprocess
import shutil

url = "http://cdn.services.gearboxsoftware.com/sparktms/poplar/pc/steam/BattlebornTMS-prod.cfg"
savedFile = url.split("/")[-1]


if os.path.exists(savedFile):
    print(f"Deleting old {savedFile} and dir...")
    os.remove(savedFile)

print(f"Requesting new {savedFile}")

with requests.get(url) as r:
    r.raise_for_status()
    with open(savedFile, "wb") as f:
        f.write(r.content)

execName = f'./Executables/Gibbed.Borderlands2.SparkTmsUnpack.exe "{savedFile}" -o'
subprocess.run(execName)


# Create a zip file
shutil.make_archive(f"./{savedFile[:-4]}", "zip", f"./{savedFile[:-4]}_unpack")
